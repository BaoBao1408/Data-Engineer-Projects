# 🗺️ Geospatial POI Pipeline

Production-grade geospatial data pipeline for **POI (Point of Interest)**, **Point Address**, and **Street Imagery** datasets — built for Ho Chi Minh City and scalable across Vietnam.

**Stack:** Python · PostgreSQL/PostGIS · GeoPandas · OpenStreetMap · Apache Airflow · FastAPI · Docker · GitHub Actions

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        DATA SOURCES                             │
│   OpenStreetMap (Overpass API)  ·  GeoJSON files  ·  APIs       │
└────────────────────────┬────────────────────────────────────────┘
                         │ Extract
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  BRONZE LAYER  raw_poi table — full raw payload + batch_id      │
└────────────────────────┬────────────────────────────────────────┘
                         │ Normalize (names, categories, coords)
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  SILVER LAYER  poi / point_address / street_imagery tables      │
│                PostGIS geometry · spatial index (GIST)          │
└────────────────────────┬────────────────────────────────────────┘
                         │ Serve
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  API LAYER     FastAPI  ·  ST_DWithin proximity  ·  GeoJSON out │
└─────────────────────────────────────────────────────────────────┘

Orchestration: Apache Airflow (daily @ 02:00 ICT)
CI/CD:         GitHub Actions → ghcr.io → Production SSH deploy
```

---

## Project Structure

```
geospatial-poi-pipeline/
├── .github/workflows/
│   ├── ci.yml              # Lint → Test → Build Docker images
│   └── cd.yml              # Deploy to production on main push
├── docker/
│   ├── Dockerfile.pipeline # One-shot ETL runner
│   ├── Dockerfile.airflow  # Airflow + geospatial deps
│   ├── Dockerfile.api      # FastAPI server
│   └── postgres/init.sh    # PostGIS setup + schema migration
├── sql/
│   ├── schema/001_create_tables.sql   # All tables + spatial indexes
│   └── queries/spatial_queries.sql   # PostGIS query examples
├── src/
│   ├── ingest/
│   │   ├── osm_extractor.py   # OpenStreetMap → GeoDataFrame
│   │   └── geojson_loader.py  # GeoJSON files → GeoDataFrame
│   ├── transform/
│   │   ├── normalizer.py      # Clean names, categories, geometry
│   │   └── deduplicator.py    # ST_DWithin spatial deduplication
│   ├── load/
│   │   └── postgis_writer.py  # Bulk insert → PostGIS
│   ├── quality/
│   │   └── validator.py       # Data quality checks
│   ├── api/
│   │   └── main.py            # FastAPI endpoints
│   └── main.py                # Pipeline entry point
├── dags/
│   └── poi_pipeline_dag.py    # Airflow DAG (5 tasks)
├── config/settings.py         # Env-based configuration
├── tests/
│   ├── unit/                  # Fast tests, no DB required
│   └── integration/           # Require running PostGIS
├── docker-compose.yml
├── Makefile                   # Dev shortcuts
└── requirements.txt
```

---

## Quick Start — End to End

### Prerequisites
- Docker + Docker Compose v2
- Git
- 4GB RAM minimum (Airflow needs ~2GB)

---

### Step 1 — Clone and configure

```bash
git clone https://github.com/BaoBao1408/geospatial-poi-pipeline.git
cd geospatial-poi-pipeline

# Copy env file and edit if needed
cp .env.example .env
```

Default `.env` works out-of-the-box for local dev. No changes needed.

---

### Step 2 — Start all services

```bash
make up
```

This starts in order:
1. **PostgreSQL + PostGIS** (port 5432) — waits for health check
2. **Airflow init** — runs `db migrate` + creates admin user
3. **Airflow webserver** (port 8080) + **scheduler**
4. **FastAPI** (port 8000)

Wait ~30 seconds for all containers to be healthy.

Verify everything is up:
```bash
docker compose ps
# All services should show "healthy" or "running"
```

---

### Step 3 — Verify PostGIS is ready

```bash
make db-spatial-check
# Expected output:
# PostGIS 3.3 ...
# count = 0   (empty table, ready for data)
```

---

### Step 4 — Run the pipeline (one-shot)

```bash
make run-pipeline
```

This runs the full ETL:
```
[1/4] Extract  → Overpass API → HCMC bbox → raw GeoDataFrame
[2/4] Normalize → clean names, categories, fix geometry
[3/4] Dedup    → in-memory (radius 20m) + cross-DB check
[4/4] Load     → bulk INSERT into PostGIS poi table
```

Expected output:
```
2024-01-15 02:00:01 | INFO     | Extracted: 8432 records
2024-01-15 02:00:05 | INFO     | After normalize: 7891 records
2024-01-15 02:00:08 | INFO     | After in-memory dedup: 7654 records
2024-01-15 02:00:45 | INFO     | After DB dedup: 7654 new records (0 duplicates)
2024-01-15 02:01:20 | INFO     | Written: 7654 records
2024-01-15 02:01:20 | INFO     | Pipeline complete in 79.3s | status=success
```

---

### Step 5 — Check data in PostGIS

```bash
make db-stats
# Shows POI count by category:
# restaurant | Ho Chi Minh City | 2841
# cafe       | Ho Chi Minh City | 1203
# hospital   | Ho Chi Minh City |  412
# ...
```

Direct SQL exploration:
```bash
make db-shell

-- Count by district
SELECT district, COUNT(*) FROM poi
GROUP BY district ORDER BY count DESC LIMIT 10;

-- Proximity search: cafes within 500m of Bến Thành
SELECT name, ST_Distance(
    geom::geography,
    ST_SetSRID(ST_MakePoint(106.6983, 10.7725), 4326)::geography
) AS distance_m
FROM poi
WHERE category = 'cafe'
AND ST_DWithin(
    geom::geography,
    ST_SetSRID(ST_MakePoint(106.6983, 10.7725), 4326)::geography,
    500
)
ORDER BY distance_m LIMIT 10;
```

---

### Step 6 — Test the API

```bash
make api-test
```

Or manually:
```bash
# Health check
curl http://localhost:8000/health

# Nearby POIs — 500m from Bến Thành Market
curl "http://localhost:8000/api/v1/poi/nearby?lon=106.6983&lat=10.7725&radius_m=500&category=cafe&limit=10"

# Bounding box — Q1 viewport
curl "http://localhost:8000/api/v1/poi/bbox?min_lon=106.68&min_lat=10.76&max_lon=106.71&max_lat=10.79"

# Stats
curl http://localhost:8000/api/v1/stats

# Swagger UI (interactive)
open http://localhost:8000/docs
```

---

### Step 7 — Airflow scheduled runs

Open Airflow UI: **http://localhost:8080**
- Username: `admin`
- Password: `admin`

1. Find DAG: `poi_pipeline_hcmc_daily`
2. Toggle **ON** to enable
3. Click ▶ to trigger manually, or wait for 02:00 ICT schedule

DAG tasks in order:
```
start → extract_osm → normalize_poi → dedup_poi → load_to_postgis → log_run_summary → end
```

---

## Running Tests

```bash
# Unit tests only (no DB needed — fast)
make test

# With coverage report
pytest tests/unit/ -v --cov=src --cov-report=html
open htmlcov/index.html

# Integration tests (requires running Docker stack)
make up
pytest tests/integration/ -v
```

---

## CI/CD Pipeline

### On every Push / PR → `main` or `develop`:
```
Lint (ruff + black + isort)
    ↓
Unit Tests (pytest + PostGIS service container)
    ↓
Build Docker images (pipeline + api)
    ↓
Push to ghcr.io
    ↓
Security scan (Trivy — CRITICAL/HIGH only)
```

### On push to `main`:
```
↓ CD workflow
SSH into production server
docker compose pull pipeline api
docker compose up -d --no-deps api
Health check curl
```

Configure secrets in GitHub → Settings → Secrets:
```
PROD_HOST      # production server IP
PROD_USER      # SSH user
PROD_SSH_KEY   # private key (PEM)
```

---

## Key PostGIS Concepts Used

| Function | Use Case |
|---|---|
| `ST_DWithin(geom, point, radius)` | Proximity search + deduplication |
| `ST_Distance(geom, point)` | Calculate exact distance |
| `ST_MakePoint(lon, lat)` | Build geometry from coordinates |
| `ST_SetSRID(..., 4326)` | Set coordinate reference (WGS84) |
| `ST_AsGeoJSON(geom)` | Export to GeoJSON format |
| `ST_MakeEnvelope(...)` | Bounding box query |
| `geom::geography` | Cast to geography for meter-accurate distance |
| `USING GIST(geom)` | Spatial index for fast queries |

---

## Extending the Pipeline

**Add a new data source:**
1. Create `src/ingest/new_source_extractor.py`
2. Return a `gpd.GeoDataFrame` with same column schema
3. Add a new task in `dags/poi_pipeline_dag.py`

**Add a new city:**
```bash
TARGET_CITY="Da Nang" TARGET_BBOX="15.9,108.0,16.2,108.4" make run-pipeline
```

**Add street imagery:**
- Extend `street_imagery` table (schema already defined)
- Link to `poi` via spatial join (nearest imagery to each POI)
